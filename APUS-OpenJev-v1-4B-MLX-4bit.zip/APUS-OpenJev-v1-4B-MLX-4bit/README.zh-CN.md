---
library_name: mlx
license: apache-2.0
base_model: apus-ailab/APUS-OpenJev-v1-4B
base_model_relation: quantized
pipeline_tag: text-generation
language:
- en
- zh
tags:
- apus-openjev
- decision-model
- mlx
- apple-silicon
---

# APUS-OpenJev-v1-4B-MLX-4bit

[English](README.md) | [中文](README.zh-CN.md) · [源模型](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B) · [Collection](https://huggingface.co/collections/apus-ailab/apus-openjev-v1-6ab1ee888eb002fcdd3a2825) · [GGUF collection](https://huggingface.co/collections/apus-ailab/apus-openjev-v1-gguf-6ab39d5e724c4d8a1021198f) · [MLX collection](https://huggingface.co/collections/apus-ailab/apus-openjev-v1-mlx-6ab39d5fc988a1b1cb89dfc8) · [MLX-8bit](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B-MLX-8bit) · [GGUF / Ollama](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B-GGUF)

[APUS-OpenJev-v1-4B](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B) 的 MLX 权重（4/6bit 混合 affine（mlx-lm `mixed_4_6`），group size 64），适用于 **Apple Silicon Mac**（mlx-lm、LM Studio）。

OpenJev 是**决策模型**：每个请求给出状态、指令和 2–16 个候选，模型对候选标签 A–P 打分。它不是聊天模型。

## 快速开始

```bash
pip install mlx-lm
hf download apus-ailab/APUS-OpenJev-v1-4B-MLX-4bit --local-dir ./openjev
python ./openjev/examples/openjev_mlx.py --model ./openjev
```

`examples/openjev_mlx.py` 使用 [openjev_contracts.py](openjev_contracts.py)（训练时的格式）渲染 prompt，返回精确的候选分布。

## 一致性

Frozen80 使用完全相同的 prompt token，与 HF BF16 发布版（完整深度，**66/80 · 82.50%**）对比：

| Run / 运行 | Backend / 后端 | Frozen80 | = HF BF16 | Max Δp |
|---|---|---:|---:|---:|
| NVIDIA RTX PRO 6000 (CUDA) | mlx 0.32.2 on Linux x86_64 (Device(gpu, 0)) | 67/80 · 83.75% | 79/80 | 0.5980 |
| Apple M5 24 GB (Metal) | mlx 0.32.2 on Darwin arm64 (Device(gpu, 0)) | 67/80 · 83.75% | 79/80 | 0.5980 |

已在 Apple M5, 24 GB 上实测：峰值内存 3.48 GB。同一份文件在 CUDA 与 Metal 上 80/80 题决策完全相同（最大 Δp 0.043）。Frozen80 是复用的开发面板，不是盲测。逐题明细（候选概率、选择、是否正确，可按 `panel_index` 与 Frozen80 关联）：[evaluation/per-question/](evaluation/per-question/)。

## 转换说明

- mlx-lm `0.31.3` / mlx `0.32.2`；4/6bit 混合 affine（mlx-lm `mixed_4_6`），group size 64。
- lm_head 及敏感层的 v_proj/down_proj 用 6bit，其余 4bit（相当于 MLX 版的 Q4_K_M）；MoE 路由门控保持 8bit（[配方](conversion.json)）。曾尝试带校准的 DWQ/GPTQ，但在转换硬件上对这种混合注意力模型不可行。
- GDN 的 `A_log` 和 `linear_attn.norm.weight` 保持源精度（35B 发布版中为 FP32）。
- 仅完整深度、仅文本，概率**未经校准**。

## 许可

Apache-2.0，继承自源模型，见 [LICENSE](LICENSE)。基座模型：[Qwen/Qwen3.5-4B](https://huggingface.co/Qwen/Qwen3.5-4B)。

**作者：** gumpcheng（[xDAN2099](https://huggingface.co/xDAN2099)）、zhangxu、[APUS AI-LAB](https://github.com/APUS-AI-Lab)。
